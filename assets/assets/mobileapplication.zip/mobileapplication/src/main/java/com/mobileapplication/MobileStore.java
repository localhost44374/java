package com.mobileapplication;

public class MobileStore
{
int id;
Mobile m1;
double price;
public MobileStore(int id, Mobile m1, double price)
{
super();
this.id = id;
this.m1 = m1;
this.price = price;
}
@Override
public String toString()
{
return "MobileStore [id=" + id + ", m1=" + m1 + ", price=" + price + "]";
}
}