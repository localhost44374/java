package com.mobileapplication;

public class Mobile
{
String brand;
String model;
public Mobile(String brand, String model)
{
super();
this.brand = brand;
this.model = model;
}
@Override
public String toString()
{
return "Mobile [brand=" + brand + ", model=" + model + "]";
}
}

