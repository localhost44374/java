package com.mobileapplication;

import org.springframework.context.*;
import org.springframework.context.support.*;
public class App {
private static ApplicationContext ctx;
public static void main(String[] args)
{
ctx = new ClassPathXmlApplicationContext("AppCtx.xml");
MobileStore m1 = (MobileStore)ctx.getBean("mobileS");
System.out.println(m1);
}
}