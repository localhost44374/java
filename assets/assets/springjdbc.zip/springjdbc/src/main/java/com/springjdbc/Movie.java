package com.springjdbc;

public class Movie
{
int mid;
String mname;
int duration;
public Movie()
{
super();
// TODO Auto-generated constructor stub
}
public Movie(int mid, String mname, int duration)
{
super();
this.mid = mid;
this.mname = mname;
this.duration = duration;
}
public int getMid() {
return mid;
}
public void setMid(int mid) {
this.mid = mid;
}
public String getMname() {
return mname;
}
public void setMname(String mname) {
this.mname = mname;
}
public int getDuration() {
return duration;
}
public void setDuration(int duration) {
this.duration = duration;
}
}
