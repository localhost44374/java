package com.springjdbc;

import org.springframework.context.*;
import org.springframework.context.support.*;
import java.util.*;
public class App {
private static ApplicationContext ctx;
public static void main(String[] args) {
ctx = new ClassPathXmlApplicationContext("AppCtx.xml");
Movie m1 = (Movie)ctx.getBean("movie");
MovieDao md = (MovieDao)ctx.getBean("movieD");
m1.setMid(105);
m1.setMname("Gadar 2");
m1.setDuration(180);
System.out.println("Inserted: " + md.saveMovie(m1));
List<Movie> mov = md.getAll();
for(Movie m : mov)
{
System.out.println(m.getMid()+"\t"+m.getMname()+"\t"+m.getDuration());
}
}
}
