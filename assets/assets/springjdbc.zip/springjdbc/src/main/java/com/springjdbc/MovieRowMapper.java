package com.springjdbc;

import java.sql.*;
import org.springframework.jdbc.core.*;
public class MovieRowMapper implements RowMapper<Movie>

{
@Override
public Movie mapRow(ResultSet arg0, int arg1) throws SQLException
{
Movie m1 = new Movie();
m1.setMid(arg0.getInt(1));
m1.setMname(arg0.getString(2));
m1.setDuration(arg0.getInt(3));
return m1;
}
}