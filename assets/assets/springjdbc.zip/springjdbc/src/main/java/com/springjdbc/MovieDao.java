package com.springjdbc;

import java.util.*;
import org.springframework.jdbc.core.*;
public class MovieDao {
JdbcTemplate jdbcT;
public MovieDao(JdbcTemplate jdbcT) {
super();
this.jdbcT = jdbcT;
}
public int saveMovie(Movie m1) {
String insQ = "INSERT INTO movies23 VALUES("+m1.getMid()+",'"+m1.getMname()+"',"+m1.getDuration()+")";
return jdbcT.update(insQ);
}
public List<Movie> getAll()
{
String selQ="SELECT * FROM movies23";
return jdbcT.query(selQ, new MovieRowMapper());
}
}

