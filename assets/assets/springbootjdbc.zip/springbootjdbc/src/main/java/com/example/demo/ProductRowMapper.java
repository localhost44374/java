package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
public class ProductRowMapper implements RowMapper<Product> {
@Override
public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
// TODO Auto-generated method stub
Product p1 = new Product();
p1.setPid(rs.getInt(1));
p1.setPname(rs.getString(2));
p1.setPdesc(rs.getString(3));
p1.setPqty(rs.getInt(4));
return p1;
}
}
