package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.*;
import java.util.*;
@Repository
public class ProductRepo {
@Autowired
JdbcTemplate jdbcT;
public List<Product> getAll()
{
String selQ = "SELECT * FROM products23";
return jdbcT.query(selQ, new ProductRowMapper());
}
public int deleteProduct(String pid)
{
String delQ = "DELETE FROM products23 where pid=?";
return jdbcT.update(delQ,Integer.parseInt(pid));
}
}