package com.example.demo;

public class Product {
int pid;
String pname;
String pdesc;
int pqty;
public Product() {
super();
// TODO Auto-generated constructor stub
}
public Product(int pid, String pname, String pdesc, int pqty) {
super();
this.pid = pid;
this.pname = pname;
this.pdesc = pdesc;
this.pqty = pqty;
}
public int getPid() {
return pid;
}
public void setPid(int pid) {
this.pid = pid;
}
public String getPname() {
return pname;
}
public void setPname(String pname) {
this.pname = pname;
}
public String getPdesc() {
return pdesc;
}
public void setPdesc(String pdesc) {
this.pdesc = pdesc;
}
public int getPqty() {
return pqty;
}
public void setPqty(int pqty) {
this.pqty = pqty;
}
}
