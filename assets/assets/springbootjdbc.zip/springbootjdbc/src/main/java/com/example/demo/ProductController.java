package com.example.demo;

import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class ProductController {
@Autowired
ProductRepo repo;
@GetMapping("/product")
public List<Product> getProducts()
{
return repo.getAll();
}
@RequestMapping(value="/product/{pid}",method=RequestMethod.DELETE)
public String deleteP(@PathVariable("pid") String pid)
{
repo.deleteProduct(pid);
return "<html><body>Object Deleted</body></html>";
}
}
