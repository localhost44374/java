package com.example.demo;

	import org.springframework.web.bind.annotation.*;
	@RestController
	public class GreetingController {
	@GetMapping("/")
	public String getWelcome()
	{
		return "<HTML><BODY><H1>Welcome to MET</H1></BODY></HTML>";
				}
				@GetMapping("/welcome")
				public String getWelcome2()
				{
				return "<HTML><BODY><H1>Welcome to MET!Everyone</H1></BODY></HTML>";
				}
				}

