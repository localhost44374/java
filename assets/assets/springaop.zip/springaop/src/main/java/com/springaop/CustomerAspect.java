package com.springaop;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.springframework.stereotype.Component;
@Aspect
@Component 
public class CustomerAspect {
@Before("execution(* com.springaop.Customer.display(..))")
void beforeAdvice() {
System.out.println("This method is called before the display method");
} 
@After("execution(* com.springaop.Customer.display(..))")
void afterAdvice() {
System.out.println("This method is called after the display method");
} 
@Around("execution(* com.springaop.Customer.display(..))")
void aroundAdvice(ProceedingJoinPoint pjp) throws Throwable {
System.out.println("----------------------------------------------------------");
pjp.proceed();
}
}
