package com.springaop;

import org.springframework.stereotype.Component;
@Component
public class Customer {
int cust_id;
String cust_name;
String cust_loc;
public Customer()
{
}
public Customer(int cust_id, String cust_name, String cust_loc) {
super();
this.cust_id = cust_id;
this.cust_name = cust_name;
this.cust_loc = cust_loc;
}
public int getCust_id() {
return cust_id;
}
public void setCust_id(int cust_id) {
this.cust_id = cust_id;
}
public String getCust_name() {
return cust_name;
}
public void setCust_name(String cust_name) {
this.cust_name = cust_name;
}
public String getCust_loc() {
return cust_loc;
}
public void setCust_loc(String cust_loc) {
this.cust_loc = cust_loc;
}
@Override
public String toString() {
return "Customer [cust_id=" + cust_id + ", cust_name=" + cust_name + ", cust_loc=" + cust_loc + "]";
}
public void display()
{
System.out.println(this.toString());
}
}
