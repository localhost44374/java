package edu.met;
public class LoginBean {
 private String uname;
 private String password;
 public LoginBean() {
 super();
 }
 public String getUname() {
 return uname;
 }
 public void setUname(String uname) {
 this.uname = uname;
 }
 public String getPassword() {
 return password;
 }
 public void setPassword(String password) {
 this.password = password;
 }
 public boolean validate() {
 if ("jaimik".equals(this.uname) && "password".equals(this.password)) {
 return true;
 } else {
 return false;
 }
 }
}