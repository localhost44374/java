package com.circulardependency.circulardependency;

public class ClassA {
	 private ClassB classB;
	 public ClassA() {
	 }
	 public ClassB getClassB() {
	return classB;
	}
	public void setClassB(ClassB classB) {
	 this.classB = classB;
	 }
}