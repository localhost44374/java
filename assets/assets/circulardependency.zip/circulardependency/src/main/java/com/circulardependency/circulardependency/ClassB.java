package com.circulardependency.circulardependency;

public class ClassB {
	 private ClassA classA;
	 public ClassB() {
	 }
	 public ClassA getClassA() {
	return classA;
	}
	 public void setClassA(ClassA classA) {
		 this.classA = classA;
		 }
}
