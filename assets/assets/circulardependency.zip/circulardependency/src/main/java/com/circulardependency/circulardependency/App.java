package com.circulardependency.circulardependency;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class App {
public static void main(String[] args) {
// Load the Spring application context from the configuration file
 ApplicationContext context = new ClassPathXmlApplicationContext("AppCtx.xml");
 // Retrieve instances of ClassA and ClassB from the context
 ClassA classA = (ClassA) context.getBean("classA");
 ClassB classB = (ClassB) context.getBean("classB");
 // Display information to verify the setup
 System.out.println("ClassA's ClassB reference: " + classA.getClassB());
 System.out.println("ClassB's ClassA reference: " + classB.getClassA());
 
}
}
