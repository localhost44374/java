package com.singerapplication.singerapplication;

import org.springframework.context.*;
import org.springframework.context.support.*;
public class App
{
private static ApplicationContext ctx;
public static void main(String[] args)
{
ctx = new ClassPathXmlApplicationContext("AppCtx.xml");
Singer s1 = (Singer)ctx.getBean("singerB");
System.out.println("s1: " + s1);
Singer s2 = (Singer)ctx.getBean("singerB");
s2.setId(102);
s2.setName("Akshay1");
System.out.println("s2: " + s2);
System.out.println("s1: " + s1);
}
}