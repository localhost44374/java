package com.singerapplication.singerapplication;

public class Singer {
int id;
String name;
public Singer(int id, String name) {
super();
this.id = id;
this.name = name;
}
public Singer() {
super();
// TODO Auto-generated constructor stub
}
public int getId() {
return id;
}
public void setId(int id) {
this.id = id;
}
public String getName() {
return name;
}
public void setName(String name) {
this.name = name;
}
@Override
public String toString() {
return "Singer [id=" + id + ", name=" + name + "]";
}
}

